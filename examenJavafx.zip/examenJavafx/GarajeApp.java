import javafx.application.Application;
import javafx.collections.FXcollections;
import javafx.collections.ObservableList;
import javafx.geometry.insets;
import javafx.scene.Scene;
import javafx.scene.control.cel.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.io;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Observable;

import javax.swing.table.TableColumn;
import javax.swing.text.TableView;

    public class GarajeApp extends Application {
        private ObservableList<Vehiculo> listaVehiculos = FXCollections.observableArrayList();
        private TableView<Vehiculo> tabla = new TableView<>();

        private TextField txtPlaca = new Textfield();
        private TextField txtModelo = new TextField();
        private ComboBox<String> cbTipo = new ComboBox<>();
        private TextField txtVelocidad = new TextField();
        private TextField txtPrecio = new TextField();

        @Override public void start(Stage primaryStage) {
            primaryStage.setTitle("Garaje de Vice City");

            cbTipo.getItems().addAll("Deportivo", "Moto", "SUV", "Lancha", "Avioneta");

            TableColumn<Vehiculo, String> colPlaca = new TableColumn<>("Placa");
            colPlaca.setCellCalueFactory(new PropertyValueFactory<>("placa"));

            TableColumn<Vehiculo, String> colModelo = new TableColumn<>("Modelo");
            colModelo.setCellCalueFactory(new PropertyValueFactory<>("modelo"));

            TableColumn<Vehiculo, String> colTipo = new TableColumn<>("Tipo");
            colTipo.setCellCalueFactory(new PropertyValueFactory<>("tipo"));

            TableColumn<Vehiculo, Integer> colVelocidad = new TableColumn<>("Velocidad Max");
            colVelocidad.setCellCalueFactory(new PropertyValueFactory<>("velocidadMax"));

            TableColumn<Vehiculo, Integer> colprecio = new TableColumn<>("Precio");
            colprecio.setCellCalueFactory(new PropertyValueFactory<>("precio"));
        
        }
    }