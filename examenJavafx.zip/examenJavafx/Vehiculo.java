import java.io.Serializable;

public class Vehiculo implements Serializable {
    private String placa;
    private String modelo;
    private String tipo;
    private int velocidadMaxima;
    private int precio;

    public Vehiculo(String placa, String modelo, String tipo, int velocidadMaxima, int precio) {
        this.placa = placa;
        this.modelo = modelo;
        this.tipo = tipo;
        this.velocidadMaxima = velocidadMaxima;
        this.precio = precio;
    }

    public String getPlaca() {
        return placa;
    } 
    public void setplaca(String placa) 
    {
        this.placa = placa;
    }
    
    public void setmodelo(String modelo) 
    {
        this.modelo = modelo;
    }

        public void settipo(String tipo) 
    {
        this.tipo = tipo;
    }

    public void setvelocidadMaxima(int velocidadMaxima) 
    {
        this.velocidadMaxima = velocidadMaxima;
    }

        public void setprecio(int precio)
    {
        this.precio = precio;
    }

    @Override
    public String toString() {
        return placa + " " + modelo;
    }
}